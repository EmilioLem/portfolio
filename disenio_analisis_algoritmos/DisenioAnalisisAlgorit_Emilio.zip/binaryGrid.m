A = mod(rand(30)*256,256) % randi([0,1],30,30);

%A = [1 1 1 2; 1 3 10 1]

image(A);

%colormap([1 1 1; 0 0 0]);

colormap(gray)
