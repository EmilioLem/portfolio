## Final thing...

#### Projects available:
* [Car](https://github.com/EmilioLem/portfolio/tree/main/disenio_analisis_algoritmos/car)
* [Viga-bola](https://github.com/EmilioLem/portfolio/tree/main/disenio_analisis_algoritmos/viga-bola)
* [Hash table research](https://github.com/EmilioLem/portfolio/blob/main/disenio_analisis_algoritmos/hashTable.md)
* [Knapsack-problem](https://github.com/EmilioLem/portfolio/tree/main/disenio_analisis_algoritmos/knapsackProblem)
* [Genetic Algoritms](https://github.com/EmilioLem/portfolio/blob/main/disenio_analisis_algoritmos/genetics.md)
* [Slow reveal of R2D2](https://github.com/EmilioLem/portfolio/blob/main/disenio_analisis_algoritmos/slowRenderImage.m)
* [Binary grid](https://github.com/EmilioLem/portfolio/blob/main/disenio_analisis_algoritmos/binaryGrid.m)
* [Monte Carlo](https://github.com/EmilioLem/portfolio/tree/main/disenio_analisis_algoritmos/MonteCarlo)
* [Hannoi](https://github.com/EmilioLem/portfolio/blob/main/disenio_analisis_algoritmos/Hannoi.m)
* [Numerical Methods of Integration](https://github.com/EmilioLem/portfolio/tree/main/disenio_analisis_algoritmos/NumericMethods)
* [Sorting algorithms](https://github.com/EmilioLem/portfolio/tree/main/disenio_analisis_algoritmos/sorting)
* [Least Square Regresion](https://github.com/EmilioLem/portfolio/tree/main/disenio_analisis_algoritmos/LeastSquaresRegresionMethods)
* [A star](https://github.com/EmilioLem/portfolio/tree/main/disenio_analisis_algoritmos/aStar)
* [Line following](https://github.com/EmilioLem/portfolio/blob/main/disenio_analisis_algoritmos/seguimiento_linea.m)
